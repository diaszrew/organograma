const axios = require("axios");
const fs = require("fs");
const admin = require("firebase-admin");

// 🔑 Inicializa o Firebase Admin com a chave de serviço
const serviceAccount = require("./serviceAccountKey.json");

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount),
});

const db = admin.firestore();

const TOKEN =
  "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwcm9maWxlX2lkIjoyMzM4ODg2LCJjb21wYW55X2lkIjo3NTIzLCJ0aW1lc3RhbXAiOjE3NTgyMTg0MjN9.Y4j6JrqS5x6Hn-QULfYkoG-FnaRVHJrKF8s8Y95OEjQ"; // substitua pela sua chave real

async function listarColaboradoresFeedz() {
  try {
    const url = "https://app.feedz.com.br/v2/integracao/employees";

    const response = await axios.get(url, {
      headers: {
        Authorization: `Bearer ${TOKEN}`,
        "Content-Type": "application/json",
      },
      params: {
        status: "Ativo",
      },
    });

    let colaboradores;
    if (Array.isArray(response.data)) {
      colaboradores = response.data;
    } else if (Array.isArray(response.data.data)) {
      colaboradores = response.data.data;
    } else {
      const firstArrayKey = Object.keys(response.data).find((k) =>
        Array.isArray(response.data[k])
      );
      if (firstArrayKey) {
        colaboradores = response.data[firstArrayKey];
      } else {
        throw new Error("Não encontrei array no retorno da API");
      }
    }

    // --- Mapeia os dados ---
    const dados = colaboradores.map((c) => ({
      id: c.id || c.employeeId || null,
      nome: c.full_name || c.name,
      email: c.email || null,
      cpf:
        c.cpf?.replace(/\D/g, "") ||
        (c.document?.replace(/\D/g, "") || null),
      cargo: c.job_description?.title ?? null,
      departamento:
        (typeof c.department === "string" && c.department) ||
        c.department_data?.name ||
        null,
      gestorDireto: c.direct_manager?.name || c.manager || null,
    }));

    // Salva também localmente
    fs.writeFileSync("colaboradores.json", JSON.stringify(dados, null, 2));

    console.log(`✅ ${dados.length} colaboradores salvos localmente`);

    // --- Envia para Firestore ---
    for (const colab of dados) {
      if (!colab.id) continue; // precisa de id único
      await db.collection("colaboradores").doc(String(colab.id)).set(colab, {
        merge: true, // mantém dados antigos se mudar só alguns campos
      });
    }

    console.log("🔥 Colaboradores salvos/atualizados no Firestore!");
  } catch (err) {
    console.error("❌ Erro ao buscar colaboradores:", err.message);
  }
}

listarColaboradoresFeedz();
