const axios = require("axios");
const fs = require("fs");

// Sua chave JWT da Feedz
const TOKEN = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJwcm9maWxlX2lkIjoyMzM4ODg2LCJjb21wYW55X2lkIjo3NTIzLCJ0aW1lc3RhbXAiOjE3NTgyMTg0MjN9.Y4j6JrqS5x6Hn-QULfYkoG-FnaRVHJrKF8s8Y95OEjQ";

async function listarColaboradoresFeedz() {
  try {
    const url = "https://app.feedz.com.br/v2/integracao/employees";

    const response = await axios.get(url, {
      headers: {
        Authorization: `Bearer ${TOKEN}`,
        "Content-Type": "application/json",
      },
      params: {
        status: "Ativo", // opcional, já é o padrão
      },
    });

    const colaboradores = response.data;

    // Mapeando apenas os campos necessários
    const dados = colaboradores.map((c) => ({
      nome: c.full_name || c.name,
      cargo: c.job_description?.title || null,
      departamento:
        c.department?.name || c.department_data?.name || null,
      gestorDireto: c.direct_manager?.name || null,
    }));

    // Salva em JSON local
    fs.writeFileSync(
      "colaboradores.json",
      JSON.stringify(dados, null, 2),
      "utf-8"
    );

    console.log(
      `✅ ${dados.length} colaboradores salvos em colaboradores.json`
    );
  } catch (err) {
    console.error(
      "❌ Erro ao buscar colaboradores:",
      err.response?.status,
      err.response?.data || err.message
    );
  }
}

listarColaboradoresFeedz();
